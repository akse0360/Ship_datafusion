import numpy as np
import torch

class Generator:
    
    # Normalize the data (optional)
    def normalize(data):
        min_val = np.min(data)
        max_val = np.max(data)
        return (data - min_val) / (max_val - min_val)

    # Encode heading as cos and sin
    def encode_heading_cos_sin(headings):
        cos_heading = np.cos(headings) #np.cos(np.radians(headings))
        sin_heading = np.sin(headings) #np.sin(np.radians(headings))
        
        return cos_heading, sin_heading

    # Generate synthetic data
    def generate_data(N, sigma): # Position only
        g = np.random.Generator(np.random.PCG64())
        x = g.uniform(0, 1, N)
        y = g.uniform(0, 1, N)
        x1 = np.clip(g.normal(x, sigma), a_min=0, a_max=1)  
        y1 = np.clip(g.normal(y, sigma), a_min=0, a_max=1)
        p1 = np.stack((x, y))
        p2 = np.stack((x1, y1))
        return p1, p2

    # Ensure calculate_heading outputs (N, 3) arrays
    def calculate_heading(p1, p2, sigma=0.05, encoding=False, missing_percentage=None):
        headings = np.arctan2(p2[1] - p1[1], p2[0] - p1[0])

        headings1 = headings + np.random.normal(0, (2 * np.pi) * sigma, len(headings))
        headings2 = headings + np.random.normal(0, (2 * np.pi) * sigma, len(headings))

        # Wrap from 0 to 2pi
        headings1 = np.mod(headings1, 2 * np.pi)
        headings2 = np.mod(headings2, 2 * np.pi)
        
        if missing_percentage is not None:
            mask = np.random.rand(len(headings)) > missing_percentage
            np.where(mask, headings, np.nan)

        if encoding:
            h1_cos, h1_sin = Generator.encode_heading_cos_sin(headings1)
            h2_cos, h2_sin = Generator.encode_heading_cos_sin(headings2)

            if missing_percentage is not None:
                # Heading 1
                h1_cos = np.where(mask, h1_cos, -1.5)
                h1_sin = np.where(mask, h1_sin, -1.5)
                # Heading 2
                h2_cos = np.where(mask, h2_cos, -1.5)
                h2_sin = np.where(mask, h2_sin, -1.5)

            t1 = np.column_stack((p1.T, h1_cos, h1_sin))
            t2 = np.column_stack((p2.T, h2_cos, h2_sin))
        else:
            if missing_percentage is not None:
                headings1 = np.where(mask, headings1, -1.5)
                headings2 = np.where(mask, headings2, -1.5)
                
            t1 = np.column_stack((p1.T, headings1))
            t2 = np.column_stack((p2.T, headings2))

        return t1, t2

    # Determine rank
    def evaluate_rankN(dist_matrix, n=5):
        # Ranking evaluation function
        def rankN(scores, labels, n=5):
            sort = torch.argsort(scores, dim=1, descending=True)
            sorted_labels = labels.gather(1, sort)
            sorted_labels = sorted_labels[torch.any(sorted_labels, dim=1)]
            correct = torch.any(sorted_labels[:, 0:n], dim=1)
            return correct.float().mean()
        
        distance_matrix = dist_matrix 
        labels = torch.eye(distance_matrix.size(0), dtype=torch.float32)
        scores = -distance_matrix  

        rank_accuracy = rankN(scores, labels, n)
        return rank_accuracy
